package com.chandana;

	public abstract class Piano
	{
	public abstract void Play();
	}

