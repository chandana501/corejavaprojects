package com.chandana;

public class Medic {
	public void displayLabel()
	{
	System.out.println("Company : Flex Pharma");
	System.out.println("Address : Pune");
	}
	}
	class Tablet extends Medic
	{
	public void displayLabel()
	{
	System.out.println("store in a cool dry place");
	}
	}
	class Syrup extends Medic
	{
	public void displayLabel()
	{
	System.out.println("Consumption as directed by the physician");
	}
	}
	class Ointment extends Medic
	{
	public void displayLabel()
	{
	System.out.println("for external use only");
	}
	}
	