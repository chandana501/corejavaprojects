package com.chandana;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class problemStatement6_1 {
public static void main(String[] args) {
	ArrayList<String> alist = new ArrayList<String>();
	int n ;
	n=new Scanner (System.in).nextInt();
	System.out.println("Enter the number of Student : ");
	for(int i=0 ;i<n;i++)
	{
		alist.add(new Scanner (System.in).next()) ;
	}
	System.out.println("Student list :");
	for (String a:alist)
	{
		System.out.println(a);
	}
	System.out.println(" Enter the name of student to be searched : ");
	String str =new Scanner (System.in).next();
	int position = Collections.binarySearch(alist, str);
	System.out.println(" Position of "+ str + " is : "+position );
	
}
}


